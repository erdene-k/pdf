# showbox-movies
herhen asaah we 

1. node index.js
oor terminal neej bgaad
2. cd movie-app
3. yarn or npm i
4. yarn dev or npm run dev
