import { useCallback, useEffect, useState } from "react";
import "./App.css";

const API_BASE_URL = "http://localhost:3001";

function App() {
  const [movies, setMovies] = useState([]);
  const [filteredMovies, setFilteredMovies] = useState([]);
  const [searchTerm, setSearchTerm] = useState("");
  const [categoryFilter, setCategoryFilter] = useState("");
  const [categories, setCategories] = useState([]);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState(null);
  const [scrapingInfo, setScrapingInfo] = useState({
    inProgress: false,
    message: "Not started",
    currentId: 0,
    totalIds: 0,
    newMoviesAddedInSession: 0,
    lastAttemptedId: 0,
  });
  const [pollingIntervalId, setPollingIntervalId] = useState(null);

  const fetchMovies = useCallback(async () => {
    setIsLoading(true);
    setError(null);
    try {
      const response = await fetch(`${API_BASE_URL}/movies`);
      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }
      const data = await response.json();
      setMovies(data);
      setFilteredMovies(data);
      const uniqueCategories = [
        ...new Set(data.map((movie) => movie.categoryTitle).filter(Boolean)),
      ];
      uniqueCategories.sort((a, b) => a.localeCompare(b));
      setCategories(uniqueCategories);
    } catch (e) {
      console.error("Failed to fetch movies:", e);
      setError(e.message);
      setMovies([]);
      setFilteredMovies([]);
      setCategories([]);
    } finally {
      setIsLoading(false);
    }
  }, []);

  useEffect(() => {
    fetchMovies();
  }, [fetchMovies]);

  useEffect(() => {
    let currentMovies = [...movies];
    if (searchTerm) {
      currentMovies = currentMovies.filter(
        (movie) =>
          movie.title?.toLowerCase().includes(searchTerm.toLowerCase()) ||
          movie.desc?.toLowerCase().includes(searchTerm.toLowerCase()) ||
          movie.desc2?.toLowerCase().includes(searchTerm.toLowerCase()) ||
          movie.desc3?.toLowerCase().includes(searchTerm.toLowerCase()) ||
          movie.categoryTitle?.toLowerCase().includes(searchTerm.toLowerCase())
      );
    }
    if (categoryFilter) {
      currentMovies = currentMovies.filter(
        (movie) => movie.categoryTitle === categoryFilter
      );
    }
    setFilteredMovies(currentMovies);
  }, [searchTerm, categoryFilter, movies]);

  const clearPolling = useCallback(() => {
    if (pollingIntervalId) {
      clearInterval(pollingIntervalId);
      setPollingIntervalId(null);
    }
  }, [pollingIntervalId]);

  const pollScrapingStatus = useCallback(async () => {
    try {
      const statusResponse = await fetch(`${API_BASE_URL}/scraping-status`);
      if (!statusResponse.ok) {
        console.error(
          "Failed to fetch scraping status:",
          statusResponse.status
        );
        return;
      }
      const statusData = await statusResponse.json();
      setScrapingInfo(statusData);

      if (!statusData.inProgress) {
        clearPolling();
        console.log(
          statusData.message || "Scraping finished. Refreshing movie list."
        );
        fetchMovies();
      }
    } catch (e) {
      console.error("Error polling scraping status:", e);
      setError("Failed to get scraping status. " + e.message);
      clearPolling();
    }
  }, [fetchMovies, clearPolling]);

  const handleRefreshMovies = async () => {
    if (scrapingInfo.inProgress) return;

    setError(null);
    setScrapingInfo((prev) => ({
      ...prev,
      inProgress: true,
      message: "Initiating refresh...",
    }));

    try {
      const response = await fetch(`${API_BASE_URL}/refresh-movies`);
      const responseData = await response.json();

      if (!response.ok && response.status !== 202) {
        throw new Error(
          responseData.message || `HTTP error! status: ${response.status}`
        );
      }

      if (responseData.status) {
        setScrapingInfo(responseData.status);
      } else {
        setScrapingInfo((prev) => ({
          ...prev,
          message: responseData.message || "Refresh initiated.",
        }));
      }

      if (responseData.status?.inProgress || response.status === 202) {
        clearPolling();
        const intervalId = setInterval(pollScrapingStatus, 2000);
        setPollingIntervalId(intervalId);
      } else {
        setScrapingInfo((prev) => ({
          ...prev,
          inProgress: false,
          message: responseData.message || "Refresh completed or not started.",
        }));
        if (response.status !== 429) {
          fetchMovies();
        }
      }
    } catch (e) {
      console.error("Failed to refresh movies:", e);
      const errorMessage = e.message || "Failed to start refresh process.";
      setError(errorMessage);
      setScrapingInfo((prev) => ({
        ...prev,
        inProgress: false,
        message: errorMessage,
      }));
      clearPolling();
    }
  };

  useEffect(() => {
    return () => {
      clearPolling();
    };
  }, [clearPolling]);

  return (
    <div className="App">
      <h1>Scraped Movie Data</h1>
      <div className="controls">
        <button
          onClick={handleRefreshMovies}
          disabled={scrapingInfo.inProgress || isLoading}
        >
          {scrapingInfo.inProgress
            ? `Refreshing... (${scrapingInfo.currentId || 0}/${
                scrapingInfo.totalIds || "?"
              })`
            : "Refresh Movies from Server"}
        </button>
        {scrapingInfo.inProgress && (
          <div className="scraping-status">
            <p>{scrapingInfo.message}</p>
            {scrapingInfo.totalIds > 0 && scrapingInfo.currentId >= 0 && (
              <progress
                value={scrapingInfo.currentId}
                max={scrapingInfo.totalIds}
                style={{ width: "100%" }}
              />
            )}
          </div>
        )}
      </div>
      <div className="filters">
        <input
          type="text"
          placeholder="Search movies..."
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
          disabled={isLoading || scrapingInfo.inProgress}
        />
        <select
          value={categoryFilter}
          onChange={(e) => setCategoryFilter(e.target.value)}
          disabled={isLoading || scrapingInfo.inProgress}
        >
          <option value="">All Categories</option>
          {categories.map((category) => (
            <option key={category} value={category}>
              {category}
            </option>
          ))}
        </select>
      </div>

      {isLoading && <p>Loading movies...</p>}
      {error && <p className="error-message">Error: {error}</p>}
      {!isLoading && !error && (
        <div className="movie-list">
          {filteredMovies.length > 0 ? (
            filteredMovies.map((movie) => (
              <div key={movie.id} className="movie-card">
                {movie.image && (
                  <img
                    src={
                      movie.image?.startsWith("http")
                        ? movie.image
                        : `${API_BASE_URL}${movie.image || ""}`
                    }
                    alt={movie.title || movie.desc || "Movie image"}
                  />
                )}
                <p>
                  <strong>Title: </strong>
                  {movie.title ||
                    movie.desc ||
                    movie.categoryTitle ||
                    "No title"}
                </p>
                <p>
                  <strong>Category:</strong> {movie.categoryTitle || "N/A"}
                </p>
                <p>{movie.desc2 || ""}</p>
                <p>{movie.desc3 || ""}</p>
                {movie.video_path && (
                  <a
                    href={movie.video_path}
                    target="_blank"
                    rel="noopener noreferrer"
                  >
                    Watch Movie
                  </a>
                )}
              </div>
            ))
          ) : (
            <p>No movies found matching your criteria, or no movies loaded.</p>
          )}
        </div>
      )}
    </div>
  );
}

export default App;
