const axios = require("axios");
const cheerio = require("cheerio");
const express = require("express");
const fs = require("fs");
const cors = require("cors"); // Import cors

const app = express();

app.use(cors()); // Enable CORS for all routes

const PORT = process.env.PORT || 3001; // Port for the scraper server
const MOVIE_DATA_FILE = "scraped_movies.json";
const BASE_URL = "http://117.85.74.97.host.secureserver.net/movie_detail/";
const MAX_MOVIE_ID = 1266; // Define your upper limit for movie IDs

let allMoviesData = [];
let lastScrapedId = 0;
// Replace isScraping with a more detailed status object
let scrapingStatus = {
  inProgress: false,
  message: "Not started",
  currentId: 0,
  totalIds: 0,
  newMoviesAddedInSession: 0,
  lastAttemptedId: 0,
};

// Load existing data from file on startup
function loadMoviesFromFile() {
  try {
    if (fs.existsSync(MOVIE_DATA_FILE)) {
      const fileData = fs.readFileSync(MOVIE_DATA_FILE, "utf-8");
      allMoviesData = JSON.parse(fileData);
      if (allMoviesData.length > 0) {
        lastScrapedId = allMoviesData.reduce(
          (maxId, movie) => Math.max(maxId, movie.id),
          0
        );
        scrapingStatus.lastAttemptedId = lastScrapedId;
        console.log(
          `Loaded ${allMoviesData.length} movies from ${MOVIE_DATA_FILE}. Last scraped ID: ${lastScrapedId}`
        );
      } else {
        console.log(
          `${MOVIE_DATA_FILE} is empty or does not contain valid movie data.`
        );
      }
    } else {
      console.log(
        `${MOVIE_DATA_FILE} not found. Starting with an empty movie list.`
      );
    }
  } catch (error) {
    console.error("Error loading movies from file:", error);
    allMoviesData = []; // Start fresh if there's an error loading
  }
}

function saveMoviesToFile() {
  try {
    fs.writeFileSync(MOVIE_DATA_FILE, JSON.stringify(allMoviesData, null, 2));
    console.log(`Data saved to ${MOVIE_DATA_FILE}`);
  } catch (error) {
    console.error("Error saving movies to file:", error);
  }
}

function extractVideoPathsFromScriptContent(scriptContent) {
  let video_path = null;
  if (!scriptContent) return { video_path };

  const entireInitMovieBlockRegex =
    /(\S*\/\/\s*function\s+initMovie\s*\(\s*\)\s*\{[\s\S]*?\/\/\s*\}\s*\S*)/m;
  const blockMatch = entireInitMovieBlockRegex.exec(scriptContent);

  if (blockMatch?.[1]) {
    const fullBlockContent = blockMatch[1];
    const itemDefinitionRegex = /\/\/\s*var\s+item\s*=\s*(\{.*?\});/m;
    const itemDefinitionMatch = itemDefinitionRegex.exec(fullBlockContent);
    const itemJsonString = itemDefinitionMatch?.[1];

    if (itemJsonString) {
      const videoPathRegex = /"video_path":\s*"([^"]+)"/;
      const matchVideoPath = videoPathRegex.exec(itemJsonString);
      if (matchVideoPath?.[1]) {
        video_path = matchVideoPath[1];
      }
    }
  }
  return { video_path };
}

async function scrapeMovie(id) {
  const url = `${BASE_URL}${id}`;
  try {
    const response = await axios.get(url, { timeout: 10000 }); // Added timeout
    const html = response.data;
    const $ = cheerio.load(html);
    let overall_video_path = null;

    const scripts = $("script");
    for (let i = 0; i < scripts.length; i++) {
      const scriptContent = $(scripts[i]).html();
      const { video_path } = extractVideoPathsFromScriptContent(scriptContent);
      if (video_path && !overall_video_path) {
        overall_video_path = video_path;
        break;
      }
    }

    const movieData = {
      id: id,
      categoryTitle: $(".movie_detail_category_title").first().text().trim(),
      desc: $(".movie_detail_desc").first().text().trim(),
      desc2: $(".movie_detail_desc2").first().text().trim(),
      desc3: $(".movie_detail_desc3").first().text().trim(),
      image: $(".movie_detail_image").first().attr("src"),
      title: $(".movie_detail_title").first().text().trim(),
      video_path: overall_video_path,
    };

    // Basic validation: ensure at least a description or category title exists
    if (!movieData.desc && !movieData.categoryTitle) {
      console.warn(
        `Skipping movie ID ${id} due to missing essential data (desc/categoryTitle).`
      );
      return null;
    }

    return movieData;
  } catch (error) {
    if (error.response && error.response.status === 404) {
      console.warn(`Movie ID ${id} not found (404).`);
    } else {
      console.error(`Error scraping movie ID ${id}:`, error.message);
    }
    return null; // Important: return null on any error to skip adding this movie
  }
}

async function runFullScrapingProcess(startId, endId) {
  scrapingStatus.inProgress = true;
  scrapingStatus.message = "Scraping started...";
  scrapingStatus.currentId = startId;
  scrapingStatus.totalIds = endId;
  scrapingStatus.newMoviesAddedInSession = 0;

  console.log(`Scraping from ID ${startId} to ${endId}`);

  for (let id = startId; id <= endId; id++) {
    scrapingStatus.currentId = id;
    scrapingStatus.message = `Scraping movie ID: ${id} of ${endId}...`;
    console.log(scrapingStatus.message);

    const movieData = await scrapeMovie(id);
    if (movieData) {
      const existingMovieIndex = allMoviesData.findIndex(
        (movie) => movie.id === movieData.id
      );
      if (existingMovieIndex !== -1) {
        allMoviesData[existingMovieIndex] = movieData;
      } else {
        allMoviesData.push(movieData);
      }
      scrapingStatus.newMoviesAddedInSession++;
    }
    lastScrapedId = id; // Update global lastScrapedId
    scrapingStatus.lastAttemptedId = id;

    if (
      scrapingStatus.newMoviesAddedInSession > 0 &&
      scrapingStatus.newMoviesAddedInSession % 20 === 0
    ) {
      saveMoviesToFile();
      console.log(
        `Intermediate progress saved. ${scrapingStatus.newMoviesAddedInSession} new movies added in this session.`
      );
      scrapingStatus.message = `Intermediate progress saved for ID ${id}.`;
    }
    // Optional delay to be less aggressive
    // await new Promise(resolve => setTimeout(resolve, 100));
  }

  saveMoviesToFile();
  scrapingStatus.inProgress = false;
  scrapingStatus.message = `Scraping finished. ${scrapingStatus.newMoviesAddedInSession} new movies added in this session. Total movies: ${allMoviesData.length}. Last attempted ID: ${lastScrapedId}`;
  console.log(scrapingStatus.message);
}

// --- Express Endpoints ---
app.get("/movies", (req, res) => {
  res.json(allMoviesData);
});

app.get("/refresh-movies", async (req, res) => {
  if (scrapingStatus.inProgress) {
    return res.status(429).json({
      message: "Scraping already in progress.",
      status: scrapingStatus,
    });
  }

  const startId = lastScrapedId + 1;
  if (startId > MAX_MOVIE_ID) {
    scrapingStatus.message = "All movies already scraped up to MAX_MOVIE_ID.";
    return res.status(200).json({
      message: scrapingStatus.message,
      status: scrapingStatus,
    });
  }

  // Run scraping in background, don't await here
  runFullScrapingProcess(startId, MAX_MOVIE_ID);

  scrapingStatus.message = "Scraping process initiated.";
  res
    .status(202)
    .json({ message: scrapingStatus.message, status: scrapingStatus });
});

app.get("/scraping-status", (req, res) => {
  res.json(scrapingStatus);
});

app.listen(PORT, () => {
  console.log(`Scraper server running on http://localhost:${PORT}`);
  loadMoviesFromFile(); // Load data when server starts
});
